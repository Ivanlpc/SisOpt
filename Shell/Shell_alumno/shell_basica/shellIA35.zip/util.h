#ifndef _UTIL_H
#define _UTIL_H

#include <stdio.h>
#include <string.h>
void parse_redirections(char **args, char **file_in, char **file_out);


#endif